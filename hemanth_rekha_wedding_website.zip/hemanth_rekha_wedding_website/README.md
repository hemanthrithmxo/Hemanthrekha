# Hemanth & Rekha Wedding Invitation Website

A responsive, single-page wedding invitation inspired by the floral mobile website reference.

## Included
- Responsive mobile and desktop layout
- Animated pink blossom decorations
- Live countdown to 1 November 2026, 8:10 AM IST
- Reception and ceremony details
- Google Maps search link for the venue
- Share Invitation button (uses the device share sheet when supported)

## Wedding details currently used
- Couple: Hemanth Kumar B N & Rekha M N
- Reception: Saturday, 31 October 2026, 7:00 PM
- Wedding ceremony: Sunday, 1 November 2026, 8:10 AM
- Venue: Sri Bommalingeshwara Kalyana Mantapa, Kachamachenahalli, Gauribidanur

If any date, time, name spelling, or venue detail needs to change, edit `index.html` and update the matching text and countdown target.

## Preview locally
Open `index.html` in a browser. For best results, test on a phone-sized viewport.

## Publish with Vercel
1. Create a new GitHub repository and upload `index.html` (and this README if desired).
2. Sign in to Vercel and choose **Add New → Project**.
3. Import the repository.
4. For a plain HTML site, leave the framework preset as **Other** and deploy.
5. Vercel will provide a public URL you can share on WhatsApp.

Alternatively, use Vercel's CLI from a folder containing `index.html`: `npx vercel --prod`.
